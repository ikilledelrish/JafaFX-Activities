package SportsCars;

public class SportsCar extends Cars {
    int turboSpeed;

    public SportsCar(String carNumber, String brand, String model, int year, int price, int turboSpeed) {
        super(carNumber, brand, model, year, price);
        this.turboSpeed = turboSpeed;
    }

    void viewTurboSpeed() {
        System.out.println("Turbo Speed: " + turboSpeed);
    }

    public void viewSportsCarStat() {
        super.displayCarInfo();
        super.displayCarDetails();
        viewTurboSpeed();
    }

    public void sportsCarDistance() {
        super.makePurchaseDecision();
        int time = 2;
        int distance = turboSpeed * time;

        System.out.println("Distance Covered: " + distance);
    }
}
