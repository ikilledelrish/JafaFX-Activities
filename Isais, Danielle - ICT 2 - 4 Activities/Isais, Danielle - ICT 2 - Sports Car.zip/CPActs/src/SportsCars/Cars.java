package SportsCars;

import java.util.Scanner;

public class Cars {
    Scanner scanner = new Scanner(System.in);

    static final String ASCII_ART =
        "_____/\\\\\\\\\\\\\\\\\\\\\\____/\\\\\\________/\\\\\\__/\\\\\\\\\\\\\\\\\\\\\\\\\\____/\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\____/\\\\\\\\\\\\\\\\\\____________/\\\\\\\\\\\\\\\\\\_____/\\\\\\\\\\\\\\\\\\_______/\\\\\\\\\\\\\\\\\\_________/\\\\\\\\\\\\\\\\\\\\\\___        \n" +
        " ___/\\\\\\/////////\\\\\\_\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\/////////\\\\\\_\\/\\\\\\///////////___/\\\\\\///////\\\\\\_______/\\\\\\////////____/\\\\\\\\\\\\\\\\\\\\\\\\\\___/\\\\\\///////\\\\\\_____/\\\\\\/////////\\\\\\_       \n" +
        "  __\\//\\\\\\______\\///__\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\_____________\\/\\\\\\_____\\/\\\\\\_____/\\\\\\/____________/\\\\\\/////////\\\\\\_\\/\\\\\\_____\\/\\\\\\____\\//\\\\\\______\\///__      \n" +
        "   ___\\////\\\\\\_________\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\\\\\\\\\\\\\\\\\\\\\/__\\/\\\\\\\\\\\\\\\\\\\\\\_____\\/\\\\\\\\\\\\\\\\\\\\\\/_____/\\\\\\_____________\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\\\\\\\\\\\\\\\\\/______\\////\\\\\\_________     \n" +
        "    ______\\////\\\\\\______\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\/////////____\\/\\\\\\///////______\\/\\\\\\//////\\\\\\____\\/\\\\\\_____________\\/\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\_\\/\\\\\\//////\\\\\\_________\\////\\\\\\______   \n" +
        "     _________\\////\\\\\\___\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\_____________\\/\\\\\\_____________\\/\\\\\\____\\//\\\\\\___\\//\\\\\\____________\\/\\\\\\/////////\\\\\\_\\/\\\\\\____\\//\\\\\\___________\\////\\\\\\___   \n" +
        "      __/\\\\\\______\\//\\\\\\__\\//\\\\\\______/\\\\\\__\\/\\\\\\_____________\\/\\\\\\_____________\\/\\\\\\_____\\//\\\\\\___\\///\\\\\\__________\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\_____\\//\\\\\\___/\\\\\\______\\//\\\\\\__  \n" +
        "       _\\///\\\\\\\\\\\\\\\\\\\\\\/____\\///\\\\\\\\\\\\\\\\\\/___\\/\\\\\\_____________\\/\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\_\\/\\\\\\______\\//\\\\\\____\\////\\\\\\\\\\\\\\\\\\_\\/\\\\\\_______\\/\\\\\\_\\/\\\\\\______\\//\\\\\\_\\///\\\\\\\\\\\\\\\\\\\\\\/___ \n" +
        "        ___\\///////////________\\/////////_____\\///______________\\///////////////__\\///________\\///________\\/////////__\\///________\\///__\\///________\\///____\\///////////_____";

    
    String carNumber, brand, model;
    int year, price, choice, paymentTerm;

  
    Cars(String carNumber, String brand, String model, int year, int price) {
        this.carNumber = carNumber;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.price = price;
    }

    void displayCarInfo() {
        System.out.println(ASCII_ART); // Print ASCII Art
        System.out.println("");
        System.out.println("Greetings! What are you looking to purchase?");
        System.out.println("\tBrand\t Model\t Year\t Price");
    }

    // Display Car Details
    void displayCarDetails() {
        System.out.println(carNumber + "\t" + brand + "\t " + model + "\t " + year + "\t " + price);
    }

    // User Input
    void makePurchaseDecision() {
        boolean validChoice = false;

        while (!validChoice) {
            System.out.println("");
            System.out.print("Select A Car: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("You Selected: " + brand + " " + model + " " + year);
                    validChoice = true;
                    break;
                case 2:
                    System.out.println("You selected: Nissan Sentra 2021");
                    validChoice = true;
                    break;
                case 3:
                    System.out.println("You selected: Honda Civic 2020");
                    validChoice = true;
                    break;
                default:
                    System.out.println("Invalid Choice. Please Select A Valid Option.");
                    // Continue Loop and Prompt for Valid Code 
            }
        }
    }

    // Calculation and Payment Information
    void calculateMonthlyPayment() {
        boolean validPaymentTerm = false;

        while (!validPaymentTerm) {
            System.out.println("\nPayment Term Options:");
            System.out.println("[1] 5 Years - 5% Interest");
            System.out.println("[2] 10 Years - 7% Interest");
            System.out.println("[3] 15 Years - 10% Interest");
            System.out.print("\nChoose A Payment Term: ");
            paymentTerm = scanner.nextInt();

            switch (paymentTerm) {
                case 1:
                    validPaymentTerm = true;
                    break;
                case 2:
                    validPaymentTerm = true;
                    break;
                case 3:
                    validPaymentTerm = true;
                    break;
                default:
                    System.out.println("Invalid Choice. Please Select A Valid Payment Term.");
                    // Continue Loop and Prompt for Valid Code again4fun
            }
        }

        double interestRate = 0;

        switch (paymentTerm) {
            case 1:
                interestRate = 0.05;
                break;
            case 2:
                interestRate = 0.07;
                break;
            case 3:
                interestRate = 0.10;
                break;
        }

        double totalPayable = calculateTotalPayable(interestRate);
        double monthlyPayment = calculateMonthlyPayment(totalPayable, paymentTerm);

        System.out.println("\nExciting Details About Your Purchase:");
        System.out.println("Total Payable: $" + String.format("%.2f", totalPayable));
        System.out.println("Monthly Payment: $" + String.format("%.2f", monthlyPayment));
        System.out.println("\nCongratulations! You're One Step Closer To Your Dream Car!");
    }

    // Total Payable Amount Calculation
    private double calculateTotalPayable(double interestRate) {
        return price * (1 + interestRate);
    }

    // Monthly Payment Calculation
    private double calculateMonthlyPayment(double totalPayable, int paymentTerm) {
        return totalPayable / paymentTerm / 12;
    }
}
