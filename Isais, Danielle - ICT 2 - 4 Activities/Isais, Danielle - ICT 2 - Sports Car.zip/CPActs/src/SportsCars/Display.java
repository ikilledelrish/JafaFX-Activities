package SportsCars;

public class Display {
    public static void main(String[] args) {
        // Attributes
        Cars c1 = new Cars("[1] ", "Toyota", "Vios", 2022, 1000000);
        Cars c2 = new Cars("[2] ", "Nissan", "Sentra", 2021, 1700000);
        Cars c3 = new Cars("[3] ", "Honda", "Civic", 2020, 1200000);
        c1.displayCarInfo();
        c1.displayCarDetails();
        c2.displayCarDetails();
        c3.displayCarDetails();
        c1.makePurchaseDecision();
        c1.calculateMonthlyPayment();

        SportsCar sportsCar = new SportsCar("[S1] ", "Ferrari", "488 GTB", 2022, 3000000, 300);
        sportsCar.viewSportsCarStat();
        sportsCar.sportsCarDistance();
    }
}
