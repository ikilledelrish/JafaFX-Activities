package Cars; 

public class Display {
    public static void main(String[] args) {
        // Car Instances
        Cars c1 = new Cars("[1] ", "Toyota", "Vios", 2022, 1000000);
        Cars c2 = new Cars("[2] ", "Nissan", "Sentra", 2021, 1700000);
        Cars c3 = new Cars("[3] ", "Honda", "Civic", 2020, 1200000);

        // Display Car Information, Details, Purchase Decision and Calculations
        c1.displayCarInfo();
        c1.displayCarDetails();
        c2.displayCarDetails();
        c3.displayCarDetails();
        c1.makePurchaseDecision();
        c1.calculateMonthlyPayment();
    }
}
