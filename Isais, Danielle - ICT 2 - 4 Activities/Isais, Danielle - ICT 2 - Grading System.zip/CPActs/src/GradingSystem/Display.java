package GradingSystem;

public class Display {

    public static void main(String[] args) {

        // Instances
        Student S = new Student("Albert Jacob", "Computer Science", "Ave Maria", 90, 88, 74);
        Student S1 = new Student("Elrish Isais", "Computer Science", "Ave Maria", 99, 96, 98);
        Student S2 = new Student("Raia Mikaela", "Academy of Pastry and Culinary Arts", "Ave Maria", 74, 74, 74);
        
        // Grading and Final Grades Display
        S.Grade();
        S.finalgrade();

        S1.Grade();
        S1.finalgrade();
        
        S2.Grade();
        S2.finalgrade();
    }
}
