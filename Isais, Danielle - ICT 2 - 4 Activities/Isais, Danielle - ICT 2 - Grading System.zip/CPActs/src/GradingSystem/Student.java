package GradingSystem;

public class Student {
    String Name, Course, Section;
    double Prelim, Midterm, Finals;

    static final String ASCII_ART =
            "  ___ ____  __  ____ __ __ _  ___    ____ _  _ ____ ____ ____ _  _ \n" +
                    " / __|  _ \\/ _\\(    (  |  ( \\/ __)  / ___| \\/ ) ___|_  _|  __| \\/ )\n" +
                    "( (_ \\)   /    \\) D ()(/    ( (_ \\  \\___ \\)  /\\___ \\ )(  ) _)/ \\/ \\\n" +
                    " \\ \\_(__\\_)_/\\_(____(__)_)__)\\___/  (____(__/ (____/(__)(____)_)(_/";

    // Static Blocked
    static {
        System.out.println(ASCII_ART);
    }
    
    Student(String Name, String Course, String Section, double Prelim, double Midterm, double Finals) {
        this.Name = Name;
        this.Course = Course;
        this.Section = Section;
        this.Prelim = Prelim;
        this.Midterm = Midterm;
        this.Finals = Finals;
    }

    void Grade() {
        System.out.println("");
        System.out.println("");
        System.out.println("Name: " + Name);
        System.out.println("Course: " + Course);
        System.out.println("Section: " + Section);
        System.out.println("");
        System.out.println("Prelim: " + Prelim);
        System.out.println("Midterm: " + Midterm);
        System.out.println("Finals: " + Finals);
    }

    void finalgrade() {
        double FinalG = Prelim * 0.3 + Midterm * 0.3 + Finals * 0.4;

        System.out.print("Final Grade: " + FinalG);

        if (FinalG >= 74.5) {
            System.out.println("");
            System.out.println("\nCongratulations! You Passed. !!!");
            System.out.println("");
            System.out.print("_____________________________________________________________________\n");
        } else {
            System.out.println("");
            System.out.println("\nFailed.");
            System.out.println("");
            System.out.print("_____________________________________________________________________");
        }
    }
}
