package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {
    private int wrongAttempts = 0;

    @Override
    public void start(Stage primaryStage) {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(2); // Decreased vertical gap to make it super close
        grid.setPadding(new Insets(25));

        Label exploreLabel = new Label("EXPLORE");
        exploreLabel.getStyleClass().add("explore-label");
        exploreLabel.setStyle("-fx-font-family: 'Lithos Black', sans-serif;-fx-translate-x: 40px; -fx-translate-y: -115;");

        // Set the "EXPLORE" label at the upper center
        StackPane stackPane = new StackPane(exploreLabel);
        stackPane.setAlignment(Pos.TOP_CENTER);
        grid.add(stackPane, 0, 0, 2, 1);

        Label userNameLabel = new Label("Username:");
        userNameLabel.getStyleClass().add("explore-label-username");
        userNameLabel.setStyle("-fx-padding: 0 0 5 0; -fx-translate-x: 170px; -fx-translate-y: -5;");
        grid.add(userNameLabel, 0, 1);

        // Load the image for username
        Image lineImage = new Image(getClass().getResourceAsStream("line.png"));
        ImageView lineImageView = new ImageView(lineImage);
        lineImageView.setFitWidth(255); // Set the width of the image
        lineImageView.setFitHeight(20); // Set the height of the image
        lineImageView.setStyle("-fx-translate-x: 165;"); // Adjust X-axis position
        grid.add(lineImageView, 0, 1); // Add image under the "Username:" label, adjusting the column index to 0

        TextField userNameTextField = new TextField(); // Text field for username
        userNameTextField.getStyleClass().add("explore-label-username");
        userNameTextField.setStyle("-fx-underline: true; -fx-translate-x: 220px; -fx-translate-y: 55px;"); // Move the text field down and adjust its horizontal position
        grid.add(userNameTextField, 0, 0, 1, 1); // Add text field to grid and make it span two columns

        Label passwordLabel = new Label("Password:");
        passwordLabel.setTranslateX(170); // Adjust x-axis position
        passwordLabel.setTranslateY(-5); // Adjust y-axis position
        grid.add(passwordLabel, 0, 3);

        // Load the image for password
        Image lineImagePassword = new Image(getClass().getResourceAsStream("line.png"));
        ImageView lineImageViewPassword = new ImageView(lineImagePassword);
        lineImageViewPassword.setFitWidth(255); // Set the width of the image
        lineImageViewPassword.setFitHeight(20); // Set the height of the image
        lineImageViewPassword.setStyle("-fx-translate-x: 165; -fx-translate-y: 5;"); // Adjust X and Y-axis position
        grid.add(lineImageViewPassword, 0, 3); // Add image under the "Password:" label, adjusting the column index to 0

        StackPane passwordPane = new StackPane();
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("");
        passwordField.setStyle("-fx-translate-x: -40px; -fx-translate-y: 20px; -fx-font-size: 5px;"); // Adjust the font size
        grid.add(passwordField, 1, 1); // Add password field to grid beside the "Username" field

        Button signUpButton = new Button("     Sign Up     ");
        signUpButton.getStyleClass().add("button-white");
        // Adjust x and y position using pixel values
        signUpButton.setTranslateX(55);
        signUpButton.setTranslateY(10);
        grid.add(signUpButton, 1, 5);

        Button signInButton = new Button("      Sign In      ");
        signInButton.getStyleClass().add("button-white");
        // Adjust x and y position using pixel values
        signInButton.setTranslateX(-95);
        signInButton.setTranslateY(10);
        grid.add(signInButton, 1, 5);

        Label messageLabel = new Label(); // Label for displaying messages
        grid.add(messageLabel, 0, 6, 2, 1); // Add the message label below the buttons, spanning two columns

        Hyperlink forgotLink = new Hyperlink("Forgot Password?");
        grid.add(forgotLink, 1, 7);
        // Adjust x and y position using pixel values
        forgotLink.setTranslateX(-20);
        forgotLink.setTranslateY(-20);

        // Load the image for "or" image
        Image orImage = new Image(getClass().getResourceAsStream("or.png"));
        ImageView orImageView = new ImageView(orImage);
        orImageView.setFitWidth(245); // Set the width of the image
        orImageView.setFitHeight(25); // Set the height of the image
        orImageView.setTranslateX(-95); // Adjust X translation
        orImageView.setTranslateY(5); // Adjust Y translation
        grid.add(orImageView, 1, 7);

        // Add the text "Sign in with your social media account"
        Label socialMediaLabel = new Label("Sign in with your social media account");
        socialMediaLabel.getStyleClass().add("explore-label"); // Add CSS class if needed
        socialMediaLabel.setStyle("-fx-translate-x: -100; -fx-translate-y: 45; -fx-font-size: 12px;"); // Adjust position and font size
        grid.add(socialMediaLabel, 1, 7);

        // Add icons for social media platforms
        
        ImageView facebookIcon = new ImageView(new Image(getClass().getResourceAsStream("facebook.png")));
        facebookIcon.setFitWidth(30); // Adjust width of the icon
        facebookIcon.setFitHeight(30); // Adjust height of the icon
        facebookIcon.setTranslateX(10); // Adjust x-axis position
        facebookIcon.setTranslateY(15); // Adjust y-axis position
        grid.add(facebookIcon, 1, 8); // Add Facebook icon under the text

        ImageView googleIcon = new ImageView(new Image(getClass().getResourceAsStream("google.png")));
        googleIcon.setFitWidth(30); // Adjust width of the icon
        googleIcon.setFitHeight(30); // Adjust height of the icon
        googleIcon.setTranslateX(235); // Adjust x-axis position
        googleIcon.setTranslateY(15); // Adjust y-axis position
        grid.add(googleIcon, 0, 8); // Add Google icon under the text

        ImageView instagramIcon = new ImageView(new Image(getClass().getResourceAsStream("apple.png")));
        instagramIcon.setFitWidth(30); // Adjust width of the icon
        instagramIcon.setFitHeight(30); // Adjust height of the icon
        instagramIcon.setTranslateX(-205); // Adjust x-axis position
        instagramIcon.setTranslateY(15); // Adjust y-axis position
        grid.add(instagramIcon, 2, 8); // Add Instagram icon under the text

        // Set action for the Sign Up button
        signUpButton.setOnAction(e -> {
            // Handle Sign Up action here
            getHostServices().showDocument("https://example.com/signup");
        });

        // Set action for the Sign In button
        signInButton.setOnAction(e -> {
            // Handle Sign In action here
            attemptLogin(userNameTextField.getText(), passwordField.getText(), messageLabel, primaryStage);
        });

        Scene loginScene = new Scene(grid, 400, 400);

        loginScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

        grid.setStyle("-fx-background-image: url('application/Background.png'); " +
                "-fx-background-size: cover;");

        primaryStage.setScene(loginScene);
        primaryStage.setTitle("Login");
        primaryStage.show();

        // Allow pressing Enter key to attempt login
        userNameTextField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                passwordField.requestFocus();
            }
        });

        passwordField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                attemptLogin(userNameTextField.getText(), passwordField.getText(), messageLabel, primaryStage);
            }
        });
    }

    private void attemptLogin(String username, String password, Label messageLabel, Stage primaryStage) {
        // Perform login validation or any other action
        if (username.equals("admin") && password.equals("admin")) {
            messageLabel.setText("Login Successful!"); // Set success message
            messageLabel.setTextFill(Color.GREEN); // Set text color to green
            // Adjust x and y position using pixel values
            messageLabel.setTranslateX(255);
            messageLabel.setTranslateY(-115);
            primaryStage.setScene(new Scene(new Second(primaryStage, primaryStage.getScene()), 400, 400)); // Redirect to the second page
        } else {
        	messageLabel.setText("Incorrect Username or Password!"); // Set error message
        	messageLabel.setTextFill(Color.RED); // Set text color to red
        	// Adjust x and y position using pixel values
        	messageLabel.setTranslateX(215);
        	messageLabel.setTranslateY(-115);

        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
