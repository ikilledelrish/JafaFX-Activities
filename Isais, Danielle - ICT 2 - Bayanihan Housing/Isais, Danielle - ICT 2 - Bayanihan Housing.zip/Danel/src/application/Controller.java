package application;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import java.util.HashMap;
import java.util.Map;

//Initialization
	public class Controller {
		@FXML
		private ComboBox<String> ltTypeCmb = new ComboBox<>();
		
		@FXML
		private ComboBox<String> hsTypeCmb = new ComboBox<>();
		
		@FXML
		private TextField yrsToPayTxtFld = new TextField(), dpAmtTxtFld = new TextField(), balTxtFld = new TextField(), ttlPybTxtFld = new TextField(), mthlyAmtTxtFld = new TextField();
		private Map<String, Double> lotP = new HashMap<>(), houseP = new HashMap<>();
		
	    @FXML
		public void initialize() {
		lotP = new HashMap<>(); lotP.put("Regular Lot", 300000.00); lotP.put("Corner Lot", 350000.00); lotP.put("VIP Lot", 500000.00);
		houseP = new HashMap<>(); houseP.put("None", 0.00); houseP.put("Bachelor Pad", 200000.00); houseP.put("Bungalow", 400000.00); houseP.put("Two-Storey", 600000.00);

		ltTypeCmb.getItems().addAll(lotP.keySet());
		hsTypeCmb.getItems().addAll(houseP.keySet());
		}
		    
	    @FXML
		public void compute() {
		String lot = ltTypeCmb.getValue();
		String house = hsTypeCmb.getValue();
		String years = yrsToPayTxtFld.getText();

// Validate Input For Years 
		if (!isYearsValid(years)) {
		yrsToPayTxtFld.setText("Invalid Input!");
		return;
		}

// Calculations Per Preferred Options
		double lotPrice = lotP.getOrDefault(lot, 0.0), housePrice = houseP.getOrDefault(house, 0.0);
		double downPayment = 0.1 * (lotPrice + housePrice), balance = lotPrice + housePrice - downPayment;
		double interest = balance * (getIRate(Integer.parseInt(years)) / 100), totalPayable = balance + interest;
		double monthlyAmount = totalPayable / (Integer.parseInt(years) * 12);

// Calculated Values Per Field
        dpAmtTxtFld.setText("₱" + String.format("%.2f", downPayment));
        balTxtFld.setText("₱" + String.format("%.2f", balance));
        ttlPybTxtFld.setText("₱" + String.format("%.2f", totalPayable));
        mthlyAmtTxtFld.setText("₱" + String.format("%.2f", monthlyAmount));
		}
	
//Validator
	    private boolean isYearsValid(String years) {
		try {
		int yearsToPay = Integer.parseInt(years);

//Only Accept Years Between 1 and 30		            
		return yearsToPay >= 1 && yearsToPay <= 30; 
		} catch (NumberFormatException e) {
		return false;
			}
		}
		
//Interest Rate For Number of Years To Pay		    
		private double getIRate(int yearsToPay) {
		return (yearsToPay >= 1 && yearsToPay <= 10) ? 30.0 :
		(yearsToPay >= 11 && yearsToPay <= 20) ? 50.0 :
		(yearsToPay >= 21 && yearsToPay <= 30) ? 70.0 : 0.0;
		    }

        public void get() {
          }
		}