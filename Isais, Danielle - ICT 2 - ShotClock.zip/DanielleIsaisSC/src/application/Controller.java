package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class Controller implements Initializable {

    @FXML
    private TextField minutesField, secondsField, millisecondsField;

    @FXML
    private Button startButton;

    @FXML
    private Label shotClockLabel;

    @FXML
    private Label timerLabel;
    
    @FXML
    private Button fourteenReset;

    private int shotClockTime = 24;
    private Timeline mainTimer;
    private Timeline shotClockTimer;
    private boolean isTimerRunning = false;

//Input Field Listeners
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        startButton.setDisable(true);
        minutesField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
        secondsField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
        millisecondsField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
    }

    private void checkInputFields() {
        boolean disableStartButton = minutesField.getText().isEmpty() || secondsField.getText().isEmpty()
                || millisecondsField.getText().isEmpty();
        startButton.setDisable(disableStartButton);
    }
    
//Update Timer Display
    @FXML
    private void setTimer() {
        String minutesStr = minutesField.getText();
        String secondsStr = secondsField.getText();
        String millisecondsStr = millisecondsField.getText();

        int minutes = Integer.parseInt(minutesStr);
        int seconds = Integer.parseInt(secondsStr);
        int milliseconds = Integer.parseInt(millisecondsStr);

        timerLabel.setText(String.format("%02d:%02d:%03d", minutes, seconds, milliseconds));
        
//Auto Reset To 24 Seconds
        shotClockTime = 24;
        shotClockLabel.setText(String.valueOf(shotClockTime));
    }

//Start Timer Controller
    @FXML
    private void startTimer() {
        if (!isTimerRunning) {
            int minutes = Integer.parseInt(minutesField.getText());
            int seconds = Integer.parseInt(secondsField.getText());
            int milliseconds = Integer.parseInt(millisecondsField.getText());
            int totalMilliseconds = minutes * 60000 + seconds * 1000 + milliseconds;
            updateTimerLabel(minutes, seconds, milliseconds);

//Play Main Timer
            if (mainTimer != null) {
                mainTimer.play();
            } else {
                startMainTimer(totalMilliseconds);
            }
            
//Play Shot Clock
            if (shotClockTimer != null) {
                shotClockTimer.play();
            } else {
                startShotClockTimer();
            }

            isTimerRunning = true;
            startButton.setText("Stop");
        } else {
        	
//Pause Main Timer      	
            if (mainTimer != null) {
                mainTimer.pause();
            }
            
//Pause Shot Clock
            if (shotClockTimer != null) {
                shotClockTimer.pause();
            }
            isTimerRunning = false;
            startButton.setText("Start");
        }
    }

//Main Timer Logic
    private void startMainTimer(int totalMilliseconds) {
        final int[] remainingMilliseconds = {totalMilliseconds};
        mainTimer = new Timeline(new KeyFrame(Duration.millis(1), e -> {
            remainingMilliseconds[0]--;
            if (remainingMilliseconds[0] >= 0) {
                int minutes = remainingMilliseconds[0] / 60000;
                int seconds = (remainingMilliseconds[0] % 60000) / 1000;
                int milliseconds = remainingMilliseconds[0] % 1000;

                updateTimerLabel(minutes, seconds, milliseconds);
            } else {
                mainTimer.stop();
                timerLabel.setText("00:00:000");
            }
        }));
        mainTimer.setCycleCount(totalMilliseconds);
        mainTimer.play();
    }

//Update Timer Label    
    private void updateTimerLabel(int minutes, int seconds, int milliseconds) {
        int totalSeconds = minutes * 60 + seconds; 
        int updatedMinutes = totalSeconds / 60; 
        int updatedSeconds = totalSeconds % 60; 
        String formattedMilliseconds = String.format("%03d", milliseconds); 
        timerLabel.setText(String.format("%02d:%02d:%s", updatedMinutes, updatedSeconds, formattedMilliseconds));
    }

//Start Shot Clock
    @FXML
    private void startShotClockTimer() {
        if (shotClockTimer == null) {
            shotClockLabel.setText(String.valueOf(shotClockTime));

            shotClockTimer = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
                shotClockTime--;
                shotClockLabel.setText(String.valueOf(shotClockTime));

                if (shotClockTime <= 0) {
                    shotClockTimer.stop();
                    stopMainTimer();
                    startButton.setText("Start");
                }
                
//Enable Disable "Reset 14 Seconds" Based On Shot Clock Value
                fourteenReset.setDisable(shotClockTime > 14);
            }));
            shotClockTimer.setCycleCount(Timeline.INDEFINITE); 
            shotClockTimer.play();
        }
    }

//Stop Main Timer
    private void stopMainTimer() {
        if (mainTimer != null) {
            mainTimer.stop();
            isTimerRunning = false;
            startButton.setText("Start");
        }
    }
    

//Increment
    @FXML
    private void incrementShotClock() {
        shotClockLabel.setText(String.valueOf(++shotClockTime));
    }

//Decrement
    @FXML
    private void decrementShotClock() {
        shotClockLabel.setText(String.valueOf(--shotClockTime));
    }

//Reset 24 Seconds
    @FXML
    private void resetShotClock1() {
        shotClockTime = 24;
        shotClockLabel.setText(String.valueOf(shotClockTime));
    }

//Reset 24 Seconds
    @FXML
    private void resetShotClock2() {
        shotClockTime = 14;
        shotClockLabel.setText(String.valueOf(shotClockTime));
    }
}