package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        try {
            // Load the background image
            Image backgroundImage = new Image("file:///C:\\Users\\Elrish\\Projects Workplace\\DanielleIsaisSC\\src\\application.jpg");
            ImageView backgroundImageView = new ImageView(backgroundImage);

            // Create a StackPane and add the background image as the bottom layer
            StackPane root = new StackPane();
            root.getChildren().add(backgroundImageView);

            // Load the main scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene.fxml"));
            root.getChildren().add(loader.load());

            // Set the scene with the StackPane as the root
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

            // Set the scene to the primary stage
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}